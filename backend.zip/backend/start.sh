#!/bin/bash
export UPSTASH_REDIS_REST_URL="https://ultimate-ape-39168.upstash.io"
export UPSTASH_REDIS_REST_TOKEN="AZkAAAIncDIxZjNkMTFjMTYyYzQ0ZWY4YTgxNDgwNjMwMTc5ZDVmMHAyMzkxNjg"
export TELEGRAM_BOT_TOKEN="8045165561:AAGOknrIrvhNo5eG8SGX06bbY49aMN0Xfq4"
export PORT=3000
node index.js
